RECIPES_PATH = "/Users/sahitiadepu/Downloads/receipe-recommendation-system-master/input/df_recipes.csv"
PARSED_PATH = "/Users/sahitiadepu/Downloads/receipe-recommendation-system-master/input/updated_recipe_data.csv"
TFIDF_ENCODING_PATH = "/Users/sahitiadepu/Downloads/receipe-recommendation-system-master/input/tfidf_encodings.pkl"
TFIDF_MODEL_PATH = "/Users/sahitiadepu/Downloads/receipe-recommendation-system-master/models/tfidf.pkl"

